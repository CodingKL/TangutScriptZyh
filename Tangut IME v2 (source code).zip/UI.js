function showPopup(popup_id){
    var overlay0 = document.getElementById("overlay0");
    overlay0.style.display = "block";
    var availInfo = document.getElementById(popup_id);
    availInfo.style.display = "flex";
}
//UI, replace closeAvailPage
function closePopup(popup_id) {
    var overlay0 = document.getElementById("overlay0");
    overlay0.style.display = "none";
    var availInfo = document.getElementById(popup_id);  
    availInfo.style.display = "none";
}


  var overlay0 = document.getElementById("overlay0");
  overlay0.onclick = function () {
closePopup("paste-arena");
  }

closePopup("paste-arena");


function show_snackbar(context){
    var ntf=document.getElementById('snackbar');
    ntf.innerHTML=context;
    ntf.classList.add("show");
    setTimeout(() => {
        ntf.classList.remove("show");
    }, 3000);
}
