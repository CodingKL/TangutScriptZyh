import http.server
import socketserver
import mimetypes
import re
import shutil
import os
cwd=os.getcwd()
print("Current working directory:", os.getcwd())
print("New working directory set to script directory:", os.path.dirname(__file__))
os.chdir(os.path.dirname(__file__))
# Ensure the MIME type for .svg is set correctly
mimetypes.add_type('image/svg+xml', '.svg')

PORT = 8080

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

Handler = CustomHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print("Serving at port", PORT)
    httpd.serve_forever()
